var myJsonData = [{
	"id": "1",
	"longitude": "13.0833",
	"latitude": "47.75",
	"description": "This is the description of POI#1",
	"altitude": "100.0",
	"name": "POI#1"
}, {
	"id": "2",
	"longitude": "13.0833",
	"latitude": "47.75",
	"description": "This is the description of POI#2",
	"altitude": "100.0",
	"name": "POI#2"
}, {
	"id": "3",
	"longitude": "13.0833",
	"latitude": "47.75",
	"description": "This is the description of POI#3",
	"altitude": "100.0",
	"name": "POI#3"
}, {
	"id": "4",
	"longitude": "13.0833",
	"latitude": "47.75",
	"description": "This is the description of POI#4",
	"altitude": "100.0",
	"name": "POI#4"
}, {
	"id": "5",
	"longitude": "13.0833",
	"latitude": "47.75",
	"description": "This is the description of POI#5",
	"altitude": "100.0",
	"name": "POI#5"
}, {
	"id": "6",
	"longitude": "13.0833",
	"latitude": "47.75",
	"description": "This is the description of POI#6",
	"altitude": "100.0",
	"name": "POI#6"
}, {
	"id": "7",
	"longitude": "13.0833",
	"latitude": "47.75",
	"description": "This is the description of POI#7",
	"altitude": "100.0",
	"name": "POI#7"
}, {
	"id": "8",
	"longitude": "13.0833",
	"latitude": "47.75",
	"description": "This is the description of POI#8",
	"altitude": "100.0",
	"name": "POI#8"
}, {
	"id": "9",
	"longitude": "13.0833",
	"latitude": "47.75",
	"description": "This is the description of POI#9",
	"altitude": "100.0",
	"name": "POI#9"
}, {
	"id": "10",
	"longitude": "13.0833",
	"latitude": "47.75",
	"description": "This is the description of POI#10",
	"altitude": "100.0",
	"name": "POI#10"
}];